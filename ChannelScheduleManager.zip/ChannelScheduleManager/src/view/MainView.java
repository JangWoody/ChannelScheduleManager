package view;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class MainView extends JFrame {
	private String outputType = "CSV";

	public MainView() {
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

		JPanel titlePanel = new JPanel();
		JLabel titleLabel = new JLabel("ä�� ������ ��ü ��ȸ �� ����");
		titleLabel.setFont(new Font("����", Font.BOLD, 15));
		titlePanel.add(titleLabel);
		mainPanel.add(titlePanel);

		JPanel labelPanel = new JPanel();
		JLabel radioLabel = new JLabel("OUTPUT ���� ���� ");
		radioLabel.setFont(new Font("����", Font.BOLD, 13));
		labelPanel.add(radioLabel);
		mainPanel.add(labelPanel);

		JPanel radioPanel = new JPanel();
		JRadioButton csvRadio = new JRadioButton("CSV(�޸��� ����)");
		JRadioButton txtRadio = new JRadioButton("TXT(������ ����)");
		csvRadio.addActionListener(new RadioActionListener());
		txtRadio.addActionListener(new RadioActionListener());
		ButtonGroup bg = new ButtonGroup();
		bg.add(csvRadio);
		bg.add(txtRadio);
		csvRadio.setSelected(true);
		radioPanel.add(csvRadio);
		radioPanel.add(txtRadio);
		mainPanel.add(radioPanel);

		JPanel btnPanel = new JPanel();
		JButton exportBtn = new JButton("��ȸ �� ����");
		exportBtn.addActionListener(new ButtonActionListener());
		btnPanel.add(exportBtn);
		mainPanel.add(exportBtn);

		add(mainPanel);
		showGUI();
	}

	public void showGUI() {
		setTitle("ä�� ������ ��ȸ");
// setSize(800, 650);
		pack();
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public class RadioActionListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			JRadioButton selectedRadio = (JRadioButton) e.getSource();
			outputType = selectedRadio.getText().substring(0, 3);
		}
	}

	public class ButtonActionListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			JButton btn = (JButton) e.getSource();
			HashMap<String, ArrayList<String>> scheduleMap = null;

			scheduleMap = Main.dbDAO.searchBatchTime();
			if (scheduleMap == null)
				return;

			JFileChooser fs = new JFileChooser("c:\\");
			fs.setDialogTitle("SAVE FILE");
			File f = null;
			if (fs.showSaveDialog(btn.getParent().getParent()) == JFileChooser.CANCEL_OPTION)
				return;
			f = new File(fs.getSelectedFile().getPath() + "." + outputType.toLowerCase());

			try {
				PrintStream ps = new PrintStream(f);
				String seperator = outputType.equals("CSV") ? "," : "\t";
				String newLine = "\n";
				ps.println("Schedule Name" + seperator + "BS Name" + seperator + "Channel Name" + seperator
						+ "Connection URL" + seperator + "Server");
				if (scheduleMap != null) {
					String server = Main.dbDAO.getDbName();
					for (String schedule : scheduleMap.keySet()) {
						ArrayList<String> temp = scheduleMap.get(schedule);
						StringBuffer sb = new StringBuffer();
						for (int i = 0; i < temp.size(); i++) {
							sb.append(schedule);
							sb.append(seperator);
							sb.append(temp.get(i++));
							sb.append(seperator);
							sb.append(temp.get(i++));
							sb.append(seperator);
							sb.append(temp.get(i));
							sb.append(seperator);
							sb.append(server);
							sb.append(newLine);
						}
						ps.print(sb.toString());
					}
				}
				ps.flush();
				ps.close();
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		}
	}
}