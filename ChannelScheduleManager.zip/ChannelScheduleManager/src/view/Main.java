package view;

import dbConn.po.DataBaseDAO;

public class Main {
	public static DataBaseDAO dbDAO = new DataBaseDAO();

	public static void main(String[] args) {
// HashMap<String, ArrayList<String>> scheduleMap = dbDAO.searchBatchTime("PMP");
// for (String str : scheduleMap.keySet()) {
// System.out.println(str);
// ArrayList<String> temp = scheduleMap.get(str);
// for (int i = 0 ; i < temp.size(); i++) {
// System.out.println(temp.get(i++) + ", " + temp.get(i));
// }
// System.out.println();
// }
		new MainView();
	}

}