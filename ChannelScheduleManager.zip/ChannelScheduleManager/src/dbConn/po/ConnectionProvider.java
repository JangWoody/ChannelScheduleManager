package dbConn.po;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;

import dbConn.FileDAO;

public class ConnectionProvider {
	private static String dbName;

	public static Connection getConnection() throws Exception {
// try {
		String URL = "";
		String ID = "";
		String PW = "";

		ArrayList<String> configArray = FileDAO.getConfig();
		if (configArray.size() < 5) {
			throw new Exception("properties file error");
		}

		String host = configArray.get(0);
		String port = configArray.get(1);
		dbName = configArray.get(2);
		ID = configArray.get(3);
		PW = configArray.get(4);
		URL = "jdbc:sap://" + host + ":" + port + "/?databaseName=" + dbName;

// Class.forName("com.sap.db.jdbc.Driver");
		return DriverManager.getConnection(URL, ID, PW);
// } catch (ClassNotFoundException e) {
// e.printStackTrace();
// }
// return null;
	}

	public static String getDbName() {
		return dbName;
	}
}