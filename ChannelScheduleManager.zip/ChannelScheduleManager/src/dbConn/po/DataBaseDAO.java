package dbConn.po;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JOptionPane;

public class DataBaseDAO {
	private Connection conn;
	private String dbName;

	public void openConn() {
		conn = null;
		try {
			conn = ConnectionProvider.getConnection();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	public void closeConn() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public HashMap<String, ArrayList<String>> searchBatchTime() {
		openConn();
		if (this.conn == null)
			return null;
		this.dbName = ConnectionProvider.getDbName();

		String query1 = "SELECT DESCRIPTION, CHANNEL_SET FROM (SELECT ID, DESCRIPTION, cast(BINTOSTR(cast(CHANNEL_SET as binary)) as varchar) AS CHANNEL_SET FROM XI_AF_ADM_SCHEDULE WHERE ENABLED = 1)";
		HashMap<String, ArrayList<String>> scheduleMap = new HashMap<String, ArrayList<String>>();
		try (Statement stmt = conn.createStatement()) {
			ResultSet rs = stmt.executeQuery(query1);
			while (rs.next()) {
				ArrayList<String> channelList = new ArrayList<String>();
				String batchTime = rs.getString(1);
				batchTime = batchTime.replaceAll(",", "");
				String channelSet = rs.getString(2);
				channelSet = (channelSet.split("\n"))[2];
				channelList.add(channelSet);
				scheduleMap.put(batchTime, channelList);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try (Statement stmt = conn.createStatement()) {
			for (String schedule : scheduleMap.keySet()) {
				ArrayList<String> temp = scheduleMap.get(schedule);
				String query2 = "SELECT CHANNELS FROM (SELECT ID, cast(BINTOSTR(cast(CHANNELS as binary)) as varchar) AS CHANNELS FROM XI_AF_ADM_SCHD_SCS) WHERE ID = '"
						+ temp.get(0) + "'";
				ResultSet rs = stmt.executeQuery(query2);
				temp.clear();
				while (rs.next()) {
					String channelID = rs.getString(1);
					String[] channelIDArr = channelID.split("\n");
					for (int i = 1; i < channelIDArr.length; i++) {
						String query3 = "SELECT SERVICE, CHANNEL, ATTRIBS FROM XI_AF_CPA_CHANNEL WHERE OBJECT_ID = '"
								+ channelIDArr[i] + "'";
						Statement stmt1 = conn.createStatement();
						ResultSet rs1 = stmt1.executeQuery(query3);
						if (rs1.next()) {
							String bsName = rs1.getString(1);
							String channelName = rs1.getString(2);

							String attributes = rs1.getString(3);
							int startNum = attributes.indexOf("connectionURL");
							if (startNum > 0) {
								startNum += 50;
								attributes = attributes.substring(startNum);
								attributes = attributes.substring(0, attributes.indexOf("<"));
								attributes = attributes.replaceAll(" ", "");
							} else {
								attributes = "NONE";
							}

							temp.add(bsName);
							temp.add(channelName);
							temp.add(attributes);
						}
						rs1.close();
						stmt1.close();
					}
				}
				rs.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		closeConn();
		return scheduleMap;
	}

	public String getDbName() {
		return dbName;
	}
}